unsigned char* coolStringEncrypt(char* data, int key, int length);
char* coolStringDecrypt(unsigned char* data, int key, int length);

void printHexString(unsigned char* data, int length);
unsigned char* parseHexString(char* data, int length);