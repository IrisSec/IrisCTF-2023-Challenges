the cool sdk
------------
encrypt all your data with this cool sdk

(c) cool guy 2023


test decryption with:
ECDDD6B8B742A2015E9DBE50C20BE8094BF3084033325A0DCFA81896CDF5826C7EA68F320FC75DA3F776
69420