#include <stdio.h>
#include <stdlib.h>

unsigned char s[256] = {
    46,159,1,121,137,172,116,199,117,24,191,57,47,
    135,13,71,4,129,75,184,217,132,249,15,95,109,
    166,173,97,68,93,216,22,85,229,21,213,189,31,
    51,134,230,247,61,79,9,67,138,38,195,198,110,
    170,175,81,73,112,220,59,111,130,96,237,140,
    215,45,90,41,254,212,146,177,197,52,65,94,83,
    128,56,0,3,72,187,8,104,100,188,32,49,167,235,
    207,163,240,154,171,98,27,39,122,209,80,143,125,
    131,157,221,126,201,35,2,70,11,252,55,164,165,
    251,142,244,174,226,202,106,43,86,92,205,239,44,
    152,200,105,10,194,181,204,182,99,84,156,136,
    113,149,5,40,242,231,192,74,214,82,66,176,64,26,
    19,119,234,20,228,69,76,101,193,28,160,120,236,
    108,139,33,241,34,161,18,219,16,248,185,208,88,
    243,186,58,36,232,118,206,91,42,107,63,114,162,
    7,218,211,54,233,78,253,14,30,48,203,223,124,
    103,190,50,153,148,53,180,77,255,178,179,115,
    158,37,123,133,210,246,87,23,89,12,127,102,6,
    155,196,225,17,168,62,150,245,250,169,183,224,
    227,141,238,145,222,151,144,147,60,25,29
};

char* coolStringEncrypt(char* data, int key, int length) {
    char* newData = malloc(length+1);
    newData[length] = '\0';
    for (int i = 0; i < length; i++) {
        unsigned char b = (unsigned char)data[i];
        
        for (int j = 0; j < 256; j++) {
            if (s[j] == b) {
                b = j;
                break;
            }
        }

        b += 73;
        b ^= key & 0xff;
        
        for (int j = 0; j < 256; j++) {
            if (s[j] == b) {
                b = 255 - j;
                break;
            }
        }

        b -= 84;
        b ^= key & 0xff;

        newData[i] = b;

        key *= b;
        key -= i * 4;
    }
    return newData;
}

char* coolStringDecrypt(char* data, int key, int length) {
    char* newData = malloc(length+1);
    newData[length] = '\0';
    for (int i = 0; i < length; i++) {
        unsigned char b = (unsigned char)data[i];
        unsigned char c = (unsigned char)data[i];

        b ^= key & 0xff;
        b += 84;
        b = s[255 - b];
        b ^= key & 0xff;
        b -= 73;
        b = s[b];

        newData[i] = b;
        
        key *= c;
        key -= i * 4;
    }
    return newData;
}

void printHexString(unsigned char* data, int length) {
    for (int i = 0; i < length; i++) {
        printf("%02X", data[i]);
    }
    printf("\n");
}
unsigned char* parseHexString(char* data, int length) {
    unsigned char* newData = malloc(length / 2 + 1);
    newData[length / 2] = '\0';
    for (int i = 0; i < length / 2; i++) {
        char* _;
        char block[3];
        block[0] = data[i*2];
        block[1] = data[i*2+1];
        block[2] = '\0';
        newData[i] = strtol(block, &_, 16);
    }
    return newData;
}