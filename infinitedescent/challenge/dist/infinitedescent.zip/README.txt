Make sure to download https://github.com/ARM-software/CMSIS_5 if you want to build.
You may need a more recent version of qemu than provided with some distributions to run this challenge locally.
The I/O on remote is quite slow, sorry.
